import cv2
import time
import requests
import firebase_admin
from firebase_admin import credentials, db
import os

# ==========================================
# 1. ADD YOUR CREDENTIALS
# ==========================================
TELEGRAM_BOT_TOKEN = "8268276031:AAEZGr2Uj9WYnM28pEAioOBVJ63aLnb2Dsc" 
TELEGRAM_CHAT_ID = "5300582004"
FIREBASE_DB_URL = "https://railshield-4384b-default-rtdb.firebaseio.com/"

# ==========================================
# 2. FIREBASE SETUP
# ==========================================
FIREBASE_CRED_PATH = "firebase_credentials.json"
db_ref = None

if os.path.exists(FIREBASE_CRED_PATH):
    try:
        cred = credentials.Certificate(FIREBASE_CRED_PATH)
        firebase_admin.initialize_app(cred, {'databaseURL': FIREBASE_DB_URL})
        db_ref = db.reference('track_monitoring/KM_102_5')
        print("[SUCCESS] Connected to Dashboard.")
    except Exception as e:
        print(f"[WARN] Firebase init failed: {e}")

# ==========================================
# 3. LITE MOTION DETECTION ENGINE
# ==========================================
cap = cv2.VideoCapture(1)
time.sleep(2) # Let camera warm up

# Read the first frame to act as our "empty track" background
ret, frame1 = cap.read()
ret, frame2 = cap.read()

last_alert_time = 0
print("Lite Simulation Started. Wave your hand in front of the camera!")

while cap.isOpened():
    # Find the absolute difference between the first and second frame
    diff = cv2.absdiff(frame1, frame2)
    gray = cv2.cvtColor(diff, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5, 5), 0)
    _, thresh = cv2.threshold(blur, 20, 255, cv2.THRESH_BINARY)
    dilated = cv2.dilate(thresh, None, iterations=3)
    contours, _ = cv2.findContours(dilated, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    
    system_status = "CLEAR"
    signal_color = (0, 255, 0)
    threat_detected = False

    for contour in contours:
        # Ignore small movements (like shadows or camera noise)
        if cv2.contourArea(contour) < 5000:
            continue
            
        # Draw a box around the movement
        (x, y, w, h) = cv2.boundingRect(contour)
        cv2.rectangle(frame1, (x, y), (x+w, y+h), (0, 0, 255), 2)
        
        system_status = "DANGER"
        signal_color = (0, 0, 255)
        threat_detected = True

    # Trigger Alerts if Motion is Detected
    if threat_detected:
        current_time = time.time()
        if current_time - last_alert_time > 10:
            print("\n[EMERGENCY] Motion detected on track!")
            
            if db_ref:
                db_ref.update({
                    'status': 'DANGER',
                    'obstruction': 'Unidentified Object (Motion)',
                    'distance_cm': 'Close Proximity',
                    'last_updated': time.strftime("%H:%M:%S")
                })
            
            if TELEGRAM_BOT_TOKEN != "YOUR_TELEGRAM_TOKEN":
                url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage?chat_id={TELEGRAM_CHAT_ID}&text=ALERT: Unknown motion on track!"
                requests.get(url)
                
            last_alert_time = current_time

    # Reset Dashboard if track is clear
    if not threat_detected and (time.time() - last_alert_time > 5):
        if db_ref:
             db_ref.update({'status': 'CLEAR', 'obstruction': 'None', 'distance_cm': '--'})

    # Draw Status on Screen
    cv2.rectangle(frame1, (10, 10), (450, 60), (0, 0, 0), -1)
    cv2.putText(frame1, f"LITE SENSOR SIGNAL: {system_status}", (20, 45), 
                cv2.FONT_HERSHEY_SIMPLEX, 0.8, signal_color, 2)

    cv2.imshow("RailShield - Lite Demo", frame1)
    
    # Read the next frame
    frame1 = frame2
    ret, frame2 = cap.read()

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()